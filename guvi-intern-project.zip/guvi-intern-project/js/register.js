
$(document).ready(function () {
  $('#registerForm').submit(function (e) {
    e.preventDefault();

    let name = $('#name').val();
    let email = $('#email').val();
    let password = $('#password').val();

    $.ajax({
      url: 'php/register.php',
      method: 'POST',
      data: { name, email, password },
      success: function (response) {
        alert(response);
        if (response.includes('success')) {
          window.location.href = 'index.html';
        }
      },
      error: function () {
        alert('Error occurred. Try again.');
      }
    });
  });
});
