<?php
$pdo = new PDO('mysql:host=localhost;dbname=guvi_internship', 'root', '', [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
?>