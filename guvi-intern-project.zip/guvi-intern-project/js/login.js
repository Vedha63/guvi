
$(document).ready(function () {
  $('#loginForm').submit(function (e) {
    e.preventDefault();

    let email = $('#email').val();
    let password = $('#password').val();

    $.ajax({
      url: 'php/login.php',
      method: 'POST',
      dataType: 'json',
      data: { email, password },
      success: function (response) {
        if (response.status === 'success') {
          localStorage.setItem('userSession', JSON.stringify({
            email: response.email,
            session_id: response.session_id
          }));
          window.location.href = 'profile.html';
        } else {
          alert(response.message);
        }
      },
      error: function () {
        alert('Login error. Try again.');
      }
    });
  });
});
